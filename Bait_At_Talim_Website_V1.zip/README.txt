BAIT AT TA'LIM ASSEGAFF - WEBSITE VERSI 1

Ini ialah prototaip laman web responsif yang direka berdasarkan gaya screenshot:
- tema gelap
- kad bulat
- biru + emas
- butang pendaftaran
- program pengajian
- maklumat pendaftaran
- mesra telefon

Seterusnya:
1. Tukar logo placeholder kepada logo sebenar.
2. Masukkan link Google Form.
3. Masukkan nombor WhatsApp.
4. Sambungkan Google Form kepada Google Sheets.
5. Jika diperlukan, bina halaman Admin untuk rekod pelajar.

Untuk hosting percuma, boleh gunakan GitHub Pages.
